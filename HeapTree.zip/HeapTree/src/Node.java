public class Node {
    Node left;
    Node right;
    int data;

    public Node(int value)
    {
        left=null;
        right=null;
        this. data=value;
    }
}
